To run, after opening DADProjSolution, simply run the Puppet Master process.

Currently it will initiate 3 Boney processes and 3 Bank processes by reading the global config.txt file.

